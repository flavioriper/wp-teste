<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.5
 */

?>
<script type="text/html" id="tmpl-fusion_facebook_page-shortcode">
		{{{ styles }}}
		<div {{{ _.fusionGetAttributes( atts ) }}}></div>
</script>
