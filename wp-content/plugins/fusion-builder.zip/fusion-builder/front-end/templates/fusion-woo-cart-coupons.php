<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_woo_cart_coupons-shortcode">
	{{{styles}}}
	<div {{{ _.fusionGetAttributes( wooCartCouponsAttr ) }}} cellspacing="0">
	{{{ cart_coupons_content }}}
	</div>
</script>
