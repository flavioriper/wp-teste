<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.3
 */

?>
<script type="text/html" id="tmpl-fusion_post_card_cart-shortcode">
	{{{ styles }}}
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{ output }}}
	</div>
</script>
