/**
 * Field template: Embed
 */
Vue.component('form-embed', {
    template: '#tmpl-wpuf-form-embed',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});