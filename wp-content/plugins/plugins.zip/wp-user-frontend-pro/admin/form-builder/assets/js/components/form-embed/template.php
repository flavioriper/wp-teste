<div class="wpuf-fields">
    <input
        type="url"
    >
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>
