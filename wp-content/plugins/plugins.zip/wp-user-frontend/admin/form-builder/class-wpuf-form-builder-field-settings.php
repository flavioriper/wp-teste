<?php
/**
 * Field settings properties
 */
class WPUF_Form_Builder_Field_Settings {

    /**
     * All field settings
     *
     * @since 2.5
     *
     * @return array
     */
    public static function get_field_settings() {
        return [];
    }
}
