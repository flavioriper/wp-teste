(function($) {
  
    /* ------------------------------------------------------------
     * Configura o tipo de Telefone automatizado para 8 o 9 digitos
     * ----------------------------------------------------------*/
 
    var SPMaskBehavior = function (val) {
        return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
    },
    
    spOptions = {
        onKeyPress: function(val, e, field, options) {
            field.mask(SPMaskBehavior.apply({}, arguments), options);
        }
    };

     /* ------------------------------------------------------------
     * Adiciona a mascara com a mascara automatizada de telefones
     * ----------------------------------------------------------*/

    $('#billing_phone').mask(SPMaskBehavior, spOptions);

    /* ------------------------------------------------------------
     * Adiciona o loader no envio do formulário de pesquisa
     * ----------------------------------------------------------*/
    if ($(".gmw-submit-field-wrapper")[0]){
        $('.gmw-form .gmw-submit-field-wrapper').append(`<img class="geocoder-search-loader" src="${get_stylesheet_uri}/assets/svg/spinner.svg" alt="Loader" />`);
        $('.gmw-form').on('submit', function(e){
            e.preventDefault();
            $('.gmw-submit-button').addClass('hide');

            setTimeout(() => {
                $('.geocoder-search-loader').addClass('visible');
            }, 300);

            e.currentTarget.submit();   
        });
    }
})(jQuery);