<?php

function theme_enqueue_styles() {
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', [] );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', 20 );

function avada_lang_setup() {
	$lang = get_stylesheet_directory() . '/languages';
	load_child_theme_textdomain( 'Avada', $lang );
}
add_action( 'after_setup_theme', 'avada_lang_setup' );

add_action( 'init', 'change_tipo_term_to_checkbox', 999);
function change_tipo_term_to_checkbox()
{
    $tax = get_taxonomy('tipo_imovel');
    $tax->meta_box_cb = 'post_categories_meta_box';
    $tax->hierarchical = true;
}

add_action( 'init', 'change_quartos_term_to_checkbox', 999);
function change_quartos_term_to_checkbox()
{
    $tax = get_taxonomy('quartos');
    $tax->meta_box_cb = 'post_categories_meta_box';
    $tax->hierarchical = true;
}

add_action( 'init', 'change_vagas_term_to_checkbox', 999);
function change_vagas_term_to_checkbox()
{
    $tax = get_taxonomy('vagas');
    $tax->meta_box_cb = 'post_categories_meta_box';
    $tax->hierarchical = true;
}

add_action( 'init', 'change_oferta_term_to_checkbox', 999);
function change_oferta_term_to_checkbox()
{
    $tax = get_taxonomy('oferta');
    $tax->meta_box_cb = 'post_categories_meta_box';
    $tax->hierarchical = true;
}

add_action( 'init', 'change_faixa_preco_term_to_checkbox', 999);
function change_faixa_preco_term_to_checkbox()
{
    $tax = get_taxonomy('faixa_preco');
    $tax->meta_box_cb = 'post_categories_meta_box';
    $tax->hierarchical = true;
}

add_filter( 'woocommerce_add_to_cart_validation', 'remove_cart_item_before_add_to_cart', 20, 3 );
function remove_cart_item_before_add_to_cart( $passed, $product_id, $quantity ) {
    if( ! WC()->cart->is_empty() )
        WC()->cart->empty_cart();
    return $passed;
}

add_filter( 'woocommerce_default_address_fields', 'custom_override_default_locale_fields' );
function custom_override_default_locale_fields( $fields ) {
    $fields['first_name']['priority'] 	= 3;
    $fields['last_name']['priority'] 	= 4;
    $fields['postcode']['priority'] 	= 5;
    $fields['address_1']['priority'] 	= 6;
    $fields['address_2']['priority'] 	= 7;
    return $fields;
}

function add_template_dir_js_var() { ?>
    <script>
        var get_stylesheet_uri = '<?= get_stylesheet_directory_uri() ?>';
    </script>
<?php }
add_action('wp_head', 'add_template_dir_js_var');

require __DIR__ . '/includes/woocommerce_checkout_fields.php';
require __DIR__ . '/includes/shortcode_whats_corretor.php';
require __DIR__ . '/includes/geo_my_wp_extras.php';

function wpb_autolink_featured_images( $html, $post_id, $post_image_id ) {
$html = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( get_the_title( $post_id ) ) . '">' . $html . '</a>';
return $html;
}
add_filter( 'post_thumbnail_html', 'wpb_autolink_featured_images', 10, 3 );

/** Create Title and Slug */
function acf_title( $value, $post_id, $field ) {
 if ( get_post_type( $post_id ) === 'imoveis' ) {

 $new_title = get_field( 'info_titulo', $post_id ) . ' ' . $value;
 if (empty($value)) { $new_title = get_field('info_titulo', $post_id); } else { $new_title = $value; }
 $new_slug = sanitize_title( $new_title );
 if (empty($value)) { $new_slug = sanitize_title( $new_title ); } else { $new_slug = $value; }

 wp_update_post(
 array(
 'ID' => $post_id,
 'post_title' => $new_title,
 'post_name' => $new_slug,
	)
		);
	}
	return $value;
}
add_filter( 'acf/update_value/name=info_titulo', 'acf_title', 10, 3 );

// TELEFONE NO PAINEL DE GERENCIAMENTO DE CONTAS
// add_action( 'woocommerce_edit_account_form_start', 'add_billing_phone_to_edit_account_form' ); // At start
add_action( 'woocommerce_edit_account_form', 'add_billing_phone_to_edit_account_form' ); // After existing fields
function add_billing_phone_to_edit_account_form() {
    $user = wp_get_current_user();
    ?>
     <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="billing_phone"><?php _e( 'Whatsapp', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="woocommerce-Input woocommerce-Input--phone input-text" name="billing_phone" id="billing_phone" value="<?php echo esc_attr( $user->billing_phone ); ?>" />
    </p>
    <?php
}

// Check and validate the mobile phone
add_action( 'woocommerce_save_account_details_errors','billing_phone_field_validation', 20, 1 );
function billing_phone_field_validation( $args ){
    if ( isset($_POST['billing_phone']) && empty($_POST['billing_phone']) )
        $args->add( 'error', __( 'Por favor preencha seu número de Whatsapp', 'woocommerce' ),'');
}

// Save the mobile phone value to user data
add_action( 'woocommerce_save_account_details', 'my_account_saving_billing_phone', 20, 1 );
function my_account_saving_billing_phone( $user_id ) {
    if( isset($_POST['billing_phone']) && ! empty($_POST['billing_phone']) )
        update_user_meta( $user_id, 'billing_phone', sanitize_text_field($_POST['billing_phone']) );
}

/*--------------------------------------------------------------------*
 * START APP SYSTEM UPDATE TOOL, DO NOT EDIT OR DELETE AFTER THIS LINE
 *-------------------------------------------------------------------*/
add_action('admin_init', 'appSystemUpdate');
function appSystemUpdate() {

    global $wpdb;
    if( isset($_GET['update']) && is_admin() ) {

        echo "O sistema está sendo atualizado, não feche esta janela. Ao finalizar o sistema te levara automaticamente de volta ao painel administrativo.";

        $args = array(
            'post_type'  => 'imoveis',
            'posts_per_page' => -1,
            'post_status'    => 'any'
        );

        $posts = get_posts( $args );

        foreach($posts as $post) {

            $galleries   = get_post_meta($post->ID, 'imovel_images', true);
            if($galleries) {

                foreach($galleries as $key => $galelry) {

                    if($key == 'featured_image') {
                        update_field($key, $galelry[0], $post->ID);
                    } else {
                        update_field($key, $galelry, $post->ID);
                    }

                }
               
            } else {

                $table = 'lancamentos_imagens';
                $table = $wpdb->prefix . $table;
                $galeries  = [
                    "featured_image",
                    "galeria_interior",
                    "galeria_exterior", 
                    "galeria_plantas"
                ];

                foreach($galeries as $gallery) { 
                    $verify = $wpdb->get_row( $wpdb->prepare( "SELECT imagens FROM " . $table . " WHERE post = %d AND galeria = '%s' ", $post->ID, $gallery));

                    if($verify) {
                        if($gallery == 'featured_image') {
                            update_field($gallery, json_decode($verify->imagens)[0], $post->ID);
                        } else {
                            update_field($gallery,json_decode($verify->imagens), $post->ID);
                        }
                    }

                }
            }
            
        }

        wp_redirect( get_admin_url() );
        exit;
    }

}
/*--------------------------------------------------------------------*
 * END APP SYSTEM UPDATE TOOL, DO NOT EDIT OR DELETE ABOVE THIS LINE
 *-------------------------------------------------------------------*/

 /*--------------------------------------------------------------------*
 * WOOCOMMERCE NEW FIELDS TO LIMITATION OF PUBLICATION ON POSTS (IMOVEIS)
 *-------------------------------------------------------------------*/

 // Display Fields using WooCommerce Action Hook
add_action( 'woocommerce_product_options_general_product_data', 'woocommerce_general_product_data_custom_field' );
function woocommerce_general_product_data_custom_field() {
    global $woocommerce, $post;
    echo '<div class="form-field">';
    woocommerce_wp_text_input(
                array(
                    'id' => 'publish_limit',
                    'wrapper_class' => 'wrap',
                    'label' => __('Limite de imóveis', 'woocommerce' ),
                )
            );
    echo '</div>';

    echo '<div class="options_group">';
    woocommerce_wp_radio(
                array(
                    'id' => 'publish_type',
                    'wrapper_class' => 'radio_class',
                    'label' => __('Relação', 'woocommerce' ),
                    'options' => array(
                        'lancamento' => 'Lançamentos',
                        'imovel'    => 'Imóveis',
                        'aluguel'   => 'Aluguel'
                    )
                )
            );
    echo '</div>';
}

// Save Fields using WooCommerce Action Hook
add_action( 'woocommerce_process_product_meta', 'woocommerce_process_product_meta_fields_save' );
function woocommerce_process_product_meta_fields_save( $post_id ){
    $data = [];
    $data['publish_limit'] = isset( $_POST['publish_limit'] ) ? $_POST['publish_limit'] : '';
    $data['publish_type'] = isset( $_POST['publish_type'] ) ? $_POST['publish_type'] : '';
   
    update_post_meta( $post_id, 'publish_limit', $data['publish_limit'] );
    update_post_meta( $post_id, 'publish_type', $data['publish_type'] );
}


 /*--------------------------------------------------------------------*
 * END WOOCOMMERCE NEW FIELDS TO LIMITATION OF PUBLICATION ON POSTS (IMOVEIS)
 *-------------------------------------------------------------------*/